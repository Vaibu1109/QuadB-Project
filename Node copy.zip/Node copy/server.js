const express = require("express");
const axios = require("axios");
const { Client } = require("pg");
const app = express();
app.use(express.json());
require("dotenv").config();
// app.use(cors());

// Create PostgreSQL client
const client = new Client({
  user: "default",
  database: process.env.POSTGRES_DATABASE,
  port: 5432,
  host: process.env.POSTGRES_HOST,
  password: process.env.POSTGRES_PASSWORD,
  ssl: true,
});

// Connect to PostgreSQL client
client
  .connect()
  .then(() => console.log("Connected to PostgreSQL"))
  .catch((err) => console.error("Connection error", err));

// ROUTES
app.get("/tickers", async (req, res) => {
  try {
    const response = await axios.get("https://api.wazirx.com/api/v2/tickers");
    const data = response.data;

    // Sorting tickers by highest volume traded
    const sortedTickers = Object.values(data);

    // Getting top 10 tickers
    const top10Tickers = sortedTickers.slice(0, 10);

    const createtable = `
      CREATE TABLE IF NOT EXISTS tableData (
      name VARCHAR(255) NOT NULL,
      last VARCHAR(255) NOT NULL,
      buy VARCHAR(255) NOT NULL,
      sell VARCHAR(255) NOT NULL,
      base_unit VARCHAR(255) NOT NULL,
      volume VARCHAR(255) NOT NULL,
      PRIMARY KEY (name)
    );
    `;
    await client.query(createtable);

    for (const ticker of top10Tickers) {
      const insertQuery = `
        INSERT INTO tableData (name, last, buy, sell, base_unit, volume)
        VALUES ($1, $2, $3, $4, $5, $6)
        ON CONFLICT (name) DO NOTHING;
      `;

      const dataValue = [
        ticker.name,
        ticker.last,
        ticker.buy,
        ticker.sell,
        ticker.base_unit,
        ticker.volume,
      ];
      await client.query(insertQuery, dataValue);
    }
    res.header("Access-Control-Allow-Origin", "*");
    res.json(top10Tickers);
  } catch (error) {
    console.error("Error fetching tickers:", error);
    res.status(500).json({ error: "Failed to fetch tickers" });
  }
});

app.listen(3000, () => {
  console.log("Node running on port 3000");
});
